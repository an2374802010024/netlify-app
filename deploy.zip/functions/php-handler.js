exports.handler = async function(event, context) {
  // Get request information
  console.log('Full event object:', JSON.stringify(event, null, 2));

  const path = event.path;
  const queryPath = event.queryStringParameters?.path || '';
  const method = event.httpMethod;
  const params = event.queryStringParameters || {};
  let body = {};

  // Parse the request body
  try {
    if (event.body) {
      body = JSON.parse(event.body);
      console.log('Parsed body:', JSON.stringify(body));
    }
  } catch (error) {
    console.error('Error parsing request body:', error);
    // Try to handle form data if JSON parsing fails
    try {
      const bodyParams = new URLSearchParams(event.body);
      body = Object.fromEntries(bodyParams);
      console.log('Parsed form data:', JSON.stringify(body));
    } catch (e) {
      console.error('Error parsing form data:', e);
      body = {};
    }
  }

  console.log('Request details:');
  console.log('- Path:', path);
  console.log('- Query path:', queryPath);
  console.log('- Method:', method);
  console.log('- Body:', JSON.stringify(body));

  // Hardcoded credentials for demonstration
  const ADMIN_USER = 'admin';
  const ADMIN_PASS = 'admin123';

  // Check if this is a login request
  const isLoginRequest =
    (queryPath.includes('/login') || path.includes('/login')) &&
    method === 'POST';

  if (isLoginRequest) {
    console.log('Processing login request...');

    // Extract credentials from different possible locations
    const username = body.username || params.username || '';
    const password = body.password || params.password || '';

    console.log(`Login attempt - Username: "${username}", Password length: ${password.length}`);

    // Check credentials
    if (username === ADMIN_USER && password === ADMIN_PASS) {
      console.log('Login successful');

      // Return success response
      return {
        statusCode: 200,
        headers: {
          'Set-Cookie': 'phonestore_auth=admin; Path=/; SameSite=Strict; Max-Age=3600',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          success: true,
          message: 'Login successful',
          redirect: '/admin.html',
          timestamp: new Date().toISOString()
        })
      };
    } else {
      console.log('Login failed - Invalid credentials');
      console.log(`Attempted username: "${username}"`);
      console.log(`Expected username: "${ADMIN_USER}"`);
      console.log(`Password match: ${password === ADMIN_PASS}`);

      // Return failure response
      return {
        statusCode: 401,
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          success: false,
          message: 'Invalid username or password',
          timestamp: new Date().toISOString()
        })
      };
    }
  }

  // Auth check endpoint
  if (queryPath.includes('/auth-check') || path.includes('/auth-check')) {
    console.log('Processing auth check request...');
    const cookies = event.headers.cookie || '';
    const isLoggedIn = cookies.includes('phonestore_auth=admin');

    console.log('Auth check - Cookies:', cookies);
    console.log('Auth check - Is logged in:', isLoggedIn);

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        isLoggedIn: isLoggedIn,
        username: isLoggedIn ? 'admin' : null,
        userRole: isLoggedIn ? 'admin' : null,
        timestamp: new Date().toISOString()
      })
    };
  }

  // Logout endpoint
  if (queryPath.includes('/logout') || path.includes('/logout')) {
    console.log('Processing logout request...');

    return {
      statusCode: 200,
      headers: {
        'Set-Cookie': 'phonestore_auth=; Path=/; SameSite=Strict; Max-Age=0',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        success: true,
        message: 'Logout successful',
        redirect: '/index.html',
        timestamp: new Date().toISOString()
      })
    };
  }

  // Default response
  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      message: 'PhoneStore API - Available endpoints: /login, /auth-check, /logout',
      requestedPath: queryPath || path,
      timestamp: new Date().toISOString()
    })
  };
};
